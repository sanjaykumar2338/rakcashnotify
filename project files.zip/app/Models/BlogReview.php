<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class BlogReview extends Model
{

    protected $guarded = [];
    protected $table = 'blogs_review';
}